Supply Agreement
====

``` <clause src="ap://minilatedeliveryandpenalty-payment@0.4.0#fb960d02f929b32b0ea4488cbd8b3b145a95ebcd7567665bf09853c3e3a5be1d" clauseid="db208494-ef61-44b9-96c6-81a9c8bbea03" clauseid="1"/>
Late Delivery and Penalty.

In case of delayed delivery of Goods, "Seller" shall pay to
"Buyer" a penalty amounting to 10.5% of the total
value of the Goods for every 2 days of delay. The total
amount of penalty shall not, however, exceed 52.0% of the
total value of the delayed goods. If the delay is more than
15 days, the Buyer is entitled to terminate this Contract.
```
